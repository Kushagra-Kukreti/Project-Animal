import Button from "./components/Button"
import Input from "./components/Input"
import { useState } from "react"

function App() {

 
  const[val,setVal] = useState<string>("");
  const[display,setDisplay] = useState(false);

  const doChange =(s:string)=>{
    setVal(s);
  }
  const doStuff = ()=>{
    setVal("");
    if(val == "papa papa papa")
    setDisplay(true)
   
    setTimeout(()=>{
       setDisplay(false)
    },5000)
  }
 
  return(
    <>
    <div 
    style={{
      gap:"0.5rem",
      display:"flex",
      justifyContent:"center",
      alignItems:"center",
      marginTop:"10%"
      
      }}
    >
      <Input val ={val} doChange={doChange}/>
      <Button doStuff={doStuff}/>
    </div>
    
    <div style={{marginTop:"2rem",}}>
    {(display == true)?
    <video  style ={{
      maxHeight: "15rem",
      display: "block",
      margin: "auto",

      borderRadius:"6rem",
      border:"solid 0.2rem red"
    }}src="./videos/animal-video.mp4" className="object-fit-contain" autoPlay></video>
  :""}
  </div>
    
    </>
  )
}
export default App
