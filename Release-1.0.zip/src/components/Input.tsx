


type inputProp = {
    val:string
    doChange:(s:string)=>void
}
const Input = ({val,doChange}:inputProp) => {
  
  return (
     <input 
     value={val}
     onChange={(e)=>doChange(e.target.value)}
     placeholder={`type "papa papa papa" `}
     style={
        {
            width:"50%",
            height:"2.5rem",
            borderRadius:"6rem",
            padding:"1.2rem",
            outline:"none",
            border:"solid 0.2rem white"
        }
     }
     >

     </input>
  )
}

export default Input
